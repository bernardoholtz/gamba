 

var lista = [];
var farmacias = []
var remedios = [];
var app = angular.module('produtos', []);
	app.controller('ctrlProdutos', function($scope,$http,$compile) {
		
		
		
	}







